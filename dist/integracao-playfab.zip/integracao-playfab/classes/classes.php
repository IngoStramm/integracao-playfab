<?php
require_once 'class-post-type.php';
require_once 'class-taxonomy.php';
require_once 'class-playfab-user.php';
require_once 'class-playfab-api.php';